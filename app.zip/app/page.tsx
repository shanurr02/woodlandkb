// app/page.tsx
import HeroSection from './components/Navbar/Herosection';

export default function Home() {
  return (
    <div>
      <HeroSection />
    </div>
  );
}
