// components/HeroSection.tsx
import Image from 'next/image';
import Link from 'next/link';

const  url = 'https://plus.unsplash.com/premium_photo-1661765778256-169bf5e561a6?w=600&auto=format&fit=crop&q=60&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxzZWFyY2h8NXx8aW50ZXJpb3IlMjBkZXNpZ258ZW58MHx8MHx8fDA%3D'; // Replace with your actual URL


const HeroSection = () => {
  return (
    <section className="px-8 py-16 md:flex items-center justify-between max-w-7xl mx-auto">
      {/* Left Content */}
      <div className="md:w-1/2 space-y-6">
        <h1 className="text-5xl font-bold text-gray-900 leading-tight">
          Interior Design
        </h1>
        <p className="text-gray-600 max-w-lg">
          Step into a world where the art of Interior Design is meticulously crafted to bring together timeless elegance and cutting-edge modern Innovation, allowing you to transform your living spaces into the epitome of luxury and sophistication
        </p>
        <Link href="#start-project">
          <button className="bg-black text-white px-6 py-3 rounded font-medium hover:opacity-90 transition">
            Start Project
          </button>
        </Link>
        {/* Stats */}
        <div className="mt-10 flex gap-10 text-center">
          <div>
            <p className="text-2xl font-bold text-gray-900">400+</p>
            <p className="text-sm text-gray-500">Project Complete</p>
          </div>
          <div>
            <p className="text-2xl font-bold text-gray-900">600+</p>
            <p className="text-sm text-gray-500">Satisfied Clients</p>
          </div>
          <div>
            <p className="text-2xl font-bold text-gray-900">100+</p>
            <p className="text-sm text-gray-500">Unique Styles</p>
          </div>
        </div>
      </div>

      {/* Right Images */}
      <div className="md:w-1/2 mt-12 md:mt-0 flex flex-col items-end space-y-6 relative">
        <div className="w-72 h-48 relative shadow-md">
          <Image
            src="/images/image.jpg"
            alt="Interior 1"
            fill
            className="object-cover rounded"
          />
        </div>
        <div className="w-80 h-52 relative shadow-md">
          <Image
            src="/img2.jpg"
            alt="Interior 2"
            fill
            className="object-cover rounded"
          />
          <div className="absolute -bottom-4 -right-4 bg-black text-white p-3 rounded">
            ↓
          </div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;
