// components/Navbar.tsx
import Link from 'next/link';

const Navbar = () => {
  return (
    <nav className="flex justify-between items-center px-8 py-4 shadow-sm bg-white">
      {/* Logo */}
      <div className="flex items-center space-x-2">
        <div className="border rounded p-1">
          <span className="text-xl font-bold text-black">V</span>
        </div>
        <span className="text-xl font-bold text-gray-800">ivaDecor</span>
      </div>

      {/* Menu */}
      <ul className="flex space-x-8 text-sm font-medium text-gray-700">
        <li>
          <Link href="/" className="hover:text-black font-semibold">Home</Link>
        </li>
        <li>
          <Link href="/services" className="hover:text-black">Services</Link>
        </li>
        <li>
          <Link href="/contact" className="hover:text-black">Contact</Link>
        </li>
        <li>
          <Link href="/support" className="hover:text-black">Support</Link>
        </li>
      </ul>

      {/* Sign Up Button */}
      <div>
        <Link href="/signup">
          <button className="bg-black text-white text-sm px-4 py-2 rounded hover:opacity-90">
            Sign Up
          </button>
        </Link>
      </div>
    </nav>
  );
};

export default Navbar;
